---
name: Precision Vault
colors:
  surface: '#0f131c'
  surface-dim: '#0f131c'
  surface-bright: '#353942'
  surface-container-lowest: '#0a0e16'
  surface-container-low: '#181c24'
  surface-container: '#1c2028'
  surface-container-high: '#262a33'
  surface-container-highest: '#31353e'
  on-surface: '#dfe2ee'
  on-surface-variant: '#c3c6d7'
  inverse-surface: '#dfe2ee'
  inverse-on-surface: '#2c3039'
  outline: '#8d90a0'
  outline-variant: '#434655'
  surface-tint: '#b4c5ff'
  primary: '#b4c5ff'
  on-primary: '#002a78'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#0053db'
  secondary: '#bcc7de'
  on-secondary: '#263143'
  secondary-container: '#3e495d'
  on-secondary-container: '#aeb9d0'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#007d55'
  on-tertiary-container: '#bdffdb'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#d8e3fb'
  secondary-fixed-dim: '#bcc7de'
  on-secondary-fixed: '#111c2d'
  on-secondary-fixed-variant: '#3c475a'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#0f131c'
  on-background: '#dfe2ee'
  surface-variant: '#31353e'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  headline-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  body-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
  code-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.5rem
  margin: 0.75rem
  space-xs: 0.25rem
  space-sm: 0.375rem
  space-md: 0.5rem
  space-lg: 0.75rem
  space-xl: 1rem
---

## Brand & Style

This design system defines an offline, zero-trust desktop utility. The tone is utilitarian, disciplined, and secure. It delivers the quiet confidence of an essential system tool rather than a consumer web app.

### Visual Style
- **Engineered Minimalism:** Every pixel, border, and millisecond of interaction latency reinforces security and local permanence.
- **Native Desktop Form Factor:** Tuned for standard 800×500 to 1200×800 window constraints. Density is tight, legible, and non-distracting.
- **Flat Depth with Crisp Edges:** Avoids heavy gradients, saturated glows, and blurred backdrops. Visual structure relies on solid background step-downs and 1px borders.

## Colors

The palette establishes an immediate sense of quiet containment. Deep slate and charcoal shades recede into the background, letting high-contrast typography and subtle status signals drive data discovery.

### Palette Architecture
- **Canvas Base (`#0B0F17`):** Primary root window and canvas background.
- **Sidebar & Inset Canvas (`#0F172A`):** Structural navigation pane and toolbar containers.
- **Card & Active Panels (`#1E293B`):** Surface containers, modal overlays, active list elements, and input backgrounds.
- **Muted Surface (`#182234`):** Secondary paneling and table alternate rows.
- **Key Border (`#334155`):** Structural boundaries, dividers, and input outlines.
- **Subtle Accent (`#2563EB`):** Interactive selections, primary actions, and focused keystroke feedback.
- **Active Focus Ring (`#3B82F6`):** Accessible outline ring for keyboard navigation.

### State & Severity
- **Success / Cryptographic Strength (`#10B981`):** Applied to password entropy bars, matched state tags, and copy-to-clipboard confirmations.
- **Destructive / Error (`#EF4444`):** Applied to master key resets, deletion confirmations, and validation errors.
- **Warning (`#F59E0B`):** Weak entropy, expiring certificates, or uncommitted local changes.

### Foreground Hierarchy
- **High Contrast (`#F8FAFC`):** Primary data labels, key identifiers, input values.
- **Secondary (`#94A3B8`):** Field labels, unselected list items, column headers.
- **De-emphasized (`#64748B`):** Hotkeys, timestamps, placeholder text, disabled states.

## Typography

The typography is built around utilitarian legibility in high-density desktop contexts. System sans-serifs provide zero layout shifts and razor-sharp rendering on standard DPI monitors.

- **Primary UI Font (Inter):** Applied across headers, metadata, descriptions, and system actions. Sizes stay within standard compact desktop limits (11px to 20px).
- **Monospace Font (JetBrains Mono):** Dedicated to cryptographic hashes, generated passwords, API tokens, and hotkey shortcuts. Monospaced rendering ensures character differentiation (e.g., `0` vs `O`, `1` vs `l`).
- **Vertical Rhythm:** Tight line-heights ensure dense vertical list capacity without causing visual collisions in high-count master-detail views.

## Layout & Spacing

This design system uses a master-detail split-pane architecture optimized for local desktop window sizes starting at 800×500.

### Structural Framework
- **Left Sidebar (Navigation & Groups):** Fixed width of 200px to 240px. Hosts categories, tags, and settings.
- **Center Vault List (Record Index):** Fluid width (minimum 260px). Displays compact list items with search/filter pins at the top.
- **Right Detail Pane (Inspection & Decryption):** Responsive width (minimum 340px). Displays decrypted credentials, password strength meters, and audit timelines.

### Sizing Rules
- **Padding & Insets:** The root canvas maintains a strict `0.75rem` outer margin. Internal module paddings use `space-md` (`0.5rem`) or `space-lg` (`0.75rem`) to maximize visible record counts.
- **Dense Grid Alignment:** Form rows use an 8px vertical grid. Compact controls use explicit 28px or 32px heights to match native desktop expectations.

## Elevation & Depth

Visual depth is communicated exclusively through tonal stepping and 1px low-contrast outlines. Drop shadows and blurs are disabled to preserve desktop rendering performance and maintain a purposeful, distraction-free aesthetic.

- **Level 0 (Canvas Base):** `#0B0F17` for the outer window host frame and status bar.
- **Level 1 (Sub-panels):** `#0F172A` with a 1px solid border (`#334155`) for the primary side panel and list viewports.
- **Level 2 (Active Cards & Modals):** `#1E293B` bounded by `#334155`. Used for selected item rows, copyable credential groups, and inspector panels.
- **Level 3 (Popovers & Context Menus):** `#1E293B` bounded by `#475569`. Floating menus employ an understated 1px edge highlight with a subtle hard-drop ambient shadow: `0 4px 6px -1px rgba(0, 0, 0, 0.5)`.

## Shapes

The design system maintains strict geometry with restrained corner radii, avoiding excessive softness or pill silhouettes.

- **Base Radius (0.25rem / 4px to 6px):** Standard for inputs, buttons, list rows, context menus, and status tags.
- **Containers & Modals (0.5rem / 8px max):** Applied only to floating utility modals or major split panes.
- **Pills / Circles:** Used exclusively for circular security state dots (e.g., green/yellow status LEDs) and icon-only badge counters.

## Components

### Buttons
- **Primary:** Background `#2563EB`, text `#F8FAFC`, 1px solid border `#3B82F6`. Hover: `#1D4ED8`. Active: `#1E40AF`.
- **Secondary / Neutral:** Background `#1E293B`, text `#F8FAFC`, 1px solid border `#334155`. Hover: `#334155`.
- **Destructive:** Background `#182234`, text `#EF4444`, 1px solid border `#EF4444` at 40% opacity. Hover: `#EF4444` solid text on red tint background (`rgba(239, 68, 68, 0.15)`).
- **Proportions:** Fixed heights of 28px (compact) and 32px (standard). Horizontal padding of `0.75rem`.

### Input Fields & Copy Blocks
- **Input Background:** `#0B0F17` with a 1px outline of `#334155`. Text is `#F8FAFC` in `JetBrains Mono` for passwords/tokens or `Inter` for metadata.
- **Focus State:** Outline transition to `#3B82F6` (1px solid) with zero external glow.
- **Inline Action Buttons:** Embedded right-aligned icon buttons (e.g., reveal password, copy to clipboard) set to `#64748B`, transitioning to `#F8FAFC` on hover.

### Secret Reveal & Entropy Indicator
- **Entropy Bar:** A 3px horizontal track placed directly beneath secret fields. Segmented into 4 stages: `#EF4444` (Weak), `#F59E0B` (Fair), `#3B82F6` (Good), `#10B981` (Strong).
- **Masking:** Render hidden data using unicode bullet glyphs (`••••••••••••`) set to `#94A3B8`. Decrypted state renders in `#F8FAFC` mono with a subtle background highlight of `#1E293B`.

### Lists & Navigation Tree
- **Row Height:** Dense 32px height for item rows.
- **Selected Row:** Solid background `#1E293B` with an absolute 2px left border indicator in `#2563EB`. Text shifts to `#F8FAFC`.
- **Hovered Row:** `#0F172A` with `#94A3B8` secondary text.

### Checkboxes & Switches
- **Checkbox:** 14×14px square, `#0B0F17` surface, 1px border `#334155`, corner radius 2px. Checked state: `#2563EB` fill with `#F8FAFC` checkmark.
- **Toggles:** Avoid sliding iOS-style round switches; use native 2-state segmented pill toggles or desktop checkmarks.

### Status Badges & Chips
- **Format:** Height 20px, font size 11px mono, corner radius 3px, padding 2px 6px.
- **Vault Status Chip:** Background `#0B0F17`, border 1px `#334155`, text `#94A3B8`. When showing security status, paired with a 6px solid dot (`#10B981` or `#EF4444`).